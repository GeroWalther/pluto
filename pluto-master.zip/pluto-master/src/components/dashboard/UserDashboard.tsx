import { User } from 'next-auth';
import React from 'react';

export default function UserDashboard({ user }: { user: User }) {
  return <div>UserDashboard</div>;
}
