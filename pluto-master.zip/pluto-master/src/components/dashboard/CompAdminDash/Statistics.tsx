import React from 'react';

export default function Statistics() {
  return <div>Statistics</div>;
}
